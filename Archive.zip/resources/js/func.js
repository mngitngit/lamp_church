export const func = {
   isMobileView: (data) => {
      if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
         return true
      } else {
         return false
      }
    }
}