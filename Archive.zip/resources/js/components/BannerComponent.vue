<template>
    <el-card shadow="hover" class="mb-3 pb-0">
        <h2>LAMP WORLDWIDE AWTA 2022</h2>
        <p>
            BE BLESSED PHYSICALLY, MATERIALLY & SPIRITUALLY <br/>
            Event Timing: DECEMBER 27-30, 2022 <br/>
            Event Place: Calamba Tent <br/>
        </p>

        <p>
            Chosen people of God in the old testament gather for a so-called solemn assembly (Leviticus 23:36, Joel 1:14) where "offering made by fire unto the Lord" are given to celebrate God. But with Christ's death as ultimate sacrifice for all, today, animal sacrifices are no longer offered. Yet true worshipers of God continue to offer & make fire in the form of praise, worship & thanksgiving. <br/><br/>

            Annually, LAMP Church gathers & invites every one to congregate for one purpose -- offer worship & thanksgiving to the Lord of lords!
        </p>
    </el-card>
</template>