<?php $__env->startSection('content'); ?>
<div class="px-4">
    <ticket-component :registration="<?php echo e($registration); ?>" />
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.registration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/smartcharts/code/lamp_church/resources/views/registration/show.blade.php ENDPATH**/ ?>